﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Helper
{
    public static class Utility
    {
        public static DateTime ConvertStringToDate(string dateString)
        {
            CultureInfo provider = CultureInfo.InvariantCulture;
            return DateTime.ParseExact(dateString, "MM/dd/yyyy", provider);
        }

        public static string ConvertDateToString(DateTime date)
        {
            return date.ToString("MM/dd/yyyy");
        }
    }
}
