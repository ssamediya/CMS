﻿using CMS.Models;
using CMS.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public interface IContactRepository
    {
        Task<List<ContactViewModel>> GetContacts();

        Task<ContactViewModel> GetContact(long? contactId);

        Task<long> AddContact(Contact contact);

        Task<long> DeleteContact(long? contactId);

        Task<long> UpdateContact(Contact contact);
    }
}
