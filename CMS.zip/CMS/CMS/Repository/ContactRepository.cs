﻿using CMS.Helper;
using CMS.Models;
using CMS.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public class ContactRepository : IContactRepository
    {
        CMSContext _context;

        public ContactRepository(CMSContext context)
        {
            _context = context;
        }

        public Task<List<ContactViewModel>> GetContacts()
        {
            if (_context != null)
            {
                return _context.Contacts.Select(x => new ContactViewModel
                {
                    BirthDate = Utility.ConvertDateToString(x.BirthDate),
                    ContactGroup = x.ContactGroup,
                    ContactId = x.Id,
                    ContactName = x.ContactName,
                    Description = x.Description,
                    IsFavorite = x.IsFavorite
                }).ToListAsync();
            }
            return null;
        }

        public Task<ContactViewModel> GetContact(long? contactId)
        {
            if (_context != null)
            {
                return _context.Contacts.Where(x => x.Id == contactId).Select(x => new ContactViewModel
                {
                    BirthDate = Utility.ConvertDateToString(x.BirthDate),
                    ContactGroup = x.ContactGroup,
                    ContactId = x.Id,
                    ContactName = x.ContactName,
                    Description = x.Description,
                    IsFavorite = x.IsFavorite
                }).FirstOrDefaultAsync();
            }
            return null;
        }

        public async Task<long> AddContact(Contact contact)
        {
            if (_context != null)
            {
                await _context.Contacts.AddAsync(contact);
                await _context.SaveChangesAsync();
                return contact.Id;
            }
            return 0;
        }

        public async Task<long> DeleteContact(long? contactId)
        {
            long result = 0;
            if (_context != null)
            {
                var contact = await _context.Contacts.FirstOrDefaultAsync(x => x.Id == contactId);
                if (contact != null)
                {
                    _context.Contacts.Remove(contact);
                    result = await _context.SaveChangesAsync();
                }
                return result;
            }
            return result;
        }

        public async Task<long> UpdateContact(Contact contact)
        {
            long result = 0;

            if (_context != null)
            {
                var model = await _context.Contacts.FirstOrDefaultAsync(x => x.Id == contact.Id);
                if(contact !=null)
                {
                    model.BirthDate = contact.BirthDate;
                    model.ContactGroup = contact.ContactGroup;
                    model.ContactName = contact.ContactName;
                    model.Description = contact.Description;
                    model.IsFavorite = contact.IsFavorite;
                    model.UpdatedDate = contact.UpdatedDate;
                    result = await _context.SaveChangesAsync();
                }
                return result;
            }
            return result;
        }
    }
}
