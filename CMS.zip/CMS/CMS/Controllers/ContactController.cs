﻿using CMS.Helper;
using CMS.Repository;
using CMS.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        IContactRepository _contactRepository;

        public ContactController(IContactRepository contactRepository)
        {
            _contactRepository = contactRepository;
        }

        [HttpGet]
        [Route("GetContacts")]
        public async Task<IActionResult> GetContacts()
        {
            try
            {
                var contacts = await _contactRepository.GetContacts();
                if (contacts == null)
                {
                    return NotFound();
                }
                return Ok(contacts);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetContact")]
        public async Task<IActionResult> GetContact(int? contactId)
        {
            if (contactId == null)
            {
                return BadRequest();
            }

            try
            {
                var contact = await _contactRepository.GetContact(contactId);

                if (contact == null)
                {
                    return NotFound();
                }

                return Ok(contact);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        [Route("DeleteContact")]
        public async Task<IActionResult> DeleteContact(long? contactId)
        {
            long result = 0;

            if (contactId == null)
            {
                return BadRequest();
            }

            try
            {
                result = await _contactRepository.DeleteContact(contactId);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok(result);
            }
            catch (Exception)
            {

                return BadRequest();
            }
        }


        [HttpPost]
        [Route("AddContact")]
        public async Task<IActionResult> AddContact([FromBody]ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var contactId = await _contactRepository.AddContact(new Models.Contact
                    {
                        BirthDate = Utility.ConvertStringToDate(model.BirthDate),
                        ContactGroup = model.ContactGroup,
                        ContactName = model.ContactName,
                        Description = model.Description,
                        IsFavorite = model.IsFavorite,
                    });
                    if (contactId > 0)
                    {
                        return Ok(contactId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpPut]
        [Route("UpdateContact")]
        public async Task<IActionResult> UpdateContact([FromBody]ContactViewModel model)
        {
            long result = 0;

            if (ModelState.IsValid)
            {
                try
                {
                    result = await _contactRepository.UpdateContact(new Models.Contact
                    {
                        BirthDate = Utility.ConvertStringToDate(model.BirthDate),
                        ContactGroup = model.ContactGroup,
                        ContactName = model.ContactName,
                        Description = model.Description,
                        IsFavorite = model.IsFavorite,
                        Id = model.ContactId,
                        UpdatedDate = DateTime.Now
                    });

                    return Ok(result);
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName ==
                             "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }

    }
}
