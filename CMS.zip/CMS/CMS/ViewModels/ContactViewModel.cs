﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.ViewModels
{
    public class ContactViewModel
    {
        public long ContactId { get; set; }
        public string ContactName { get; set; }
        public string BirthDate { get; set; } // Get and Return date in the format mm/dd/yyyy
        public string ContactGroup { get; set; }
        public string Description { get; set; }
        public bool IsFavorite { get; set; }
    }
}
