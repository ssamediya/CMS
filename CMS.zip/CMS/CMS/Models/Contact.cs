﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CMS.Models
{
    public partial class Contact
    {
        public long Id { get; set; }
        public string ContactName { get; set; }
        public DateTime BirthDate { get; set; }
        public string ContactGroup { get; set; }
        public string Description { get; set; }
        public bool IsFavorite { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
