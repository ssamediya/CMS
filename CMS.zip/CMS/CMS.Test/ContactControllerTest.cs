﻿using CMS.Controllers;
using CMS.Models;
using CMS.Repository;
using CMS.ViewModels;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CMS.Test
{
    public class ContactControllerTest
    {
        CMSContext _context;
        ContactController _controller;
        IContactRepository _repository;

        public ContactControllerTest()
        {
            _context = new CMSContext();
            _repository = new ContactRepository(_context);
            _controller = new ContactController(_repository);
        }


        [Fact]
        public void Add_InvalidObjectPassed_ReturnsBadRequest()
        {
            // Arrange
            var dobWrongFormatItem = new ContactViewModel()
            {
                BirthDate = "2000/12/12",
                ContactGroup = "Test Contact Group",
                ContactId = 0,
                ContactName = "Test Contact Name",
                Description = "Test Description",
                IsFavorite = false
            };
            // Act
            var badResponse = _controller.AddContact(dobWrongFormatItem);
            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(badResponse);
        }

        [Fact]
        public void Add_ValidObjectPassed_ReturnsCreatedResponse()
        {
            // Arrange
            ContactViewModel testItem = new ContactViewModel()
            {
                BirthDate = "12/12/1991",
                ContactGroup = "Test Contact Group 1",
                ContactId = 0,
                ContactName = "Test Contact Name 1",
                Description = "Test Description 1",
                IsFavorite = false
            };
            // Act
            var createdResponse = _controller.AddContact(testItem);
            // Assert
            Assert.IsInstanceOf<CreatedAtActionResult>(createdResponse);
        }
    }
}
