<template>
  <div>
    <v-app id="inspire">
      <v-data-table
        :headers="headers"
        :items="contacts"
        sort-by="calories"
        class="elevation-1"
      >
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Contact List</v-toolbar-title>
            <v-divider class="mx-4" inset vertical></v-divider>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialog" max-width="500px">
              <template v-slot:activator="{ on, attrs }">
                <v-btn
                  color="primary"
                  dark
                  class="mb-2"
                  v-bind="attrs"
                  v-on="on"
                >
                  Add
                </v-btn>
              </template>
              <v-card>
                <v-card-title>
                  <span class="headline">{{ formTitle }}</span>
                </v-card-title>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-text-field
                        v-model="editedItem.contactName"
                        v-validate="'required'"
                        name="Contact Name"
                        label="Contact Name"
                      ></v-text-field>
                      </v-row>
                      <v-row>
                      <p
                        class="validation-error"
                        v-if="errors.has('Contact Name')"
                      >
                        {{ errors.first("Contact Name") }}
                      </p>
                    </v-row>

                    <v-row>
                      <v-text-field
                        v-model="editedItem.birthDate"
                        name="Birth Date"
                        v-validate="'required'"
                        label="Birth Date"
                        hint="MM/DD/YYYY"
                      ></v-text-field>
                      </v-row>
                      <v-row>
                      <p
                        class="validation-error"
                        v-if="errors.has('Birth Date')"
                      >
                        {{ errors.first("Birth Date") }}
                      </p>
                    </v-row>

                    <v-row>
                      <v-text-field
                        v-model="editedItem.contactGroup"
                        label="Contact Group"
                        v-validate="'required'"
                        name="Contact Group"
                      ></v-text-field>
                      </v-row>
                      <v-row>
                      <p
                        class="validation-error"
                        v-if="errors.has('Contact Group')"
                      >
                        {{ errors.first("Contact Group") }}
                      </p>
                    </v-row>

                    <v-row>
                      <v-text-field
                        v-model="editedItem.description"
                        label="Description"
                      ></v-text-field>
                    </v-row>

                    <v-row>
                      <v-checkbox
                        v-model="editedItem.isFavorite"
                        label="Favorite"
                      ></v-checkbox>
                    </v-row>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="close">
                    Cancel
                  </v-btn>
                  <v-btn color="blue darken-1" text @click="save"> Save </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
            <v-dialog v-model="dialogDelete" max-width="500px">
              <v-card>
                <v-card-title class="headline"
                  >Are you sure you want to delete this item?</v-card-title
                >
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closeDelete"
                    >Cancel</v-btn
                  >
                  <v-btn color="blue darken-1" text @click="deleteItemConfirm"
                    >OK</v-btn
                  >
                  <v-spacer></v-spacer>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </v-toolbar>
        </template>
        <template v-slot:item.isFavorite="{ item }">
          <v-simple-checkbox
            v-model="item.isFavorite"
            disabled
          ></v-simple-checkbox>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-icon small class="mr-2" @click="editItem(item)">
            mdi-pencil
          </v-icon>
          <v-icon small @click="deleteItem(item)"> mdi-delete </v-icon>
        </template>
      </v-data-table>
    </v-app>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { IContact } from "../common/types";
import {
  getContacts,
  addContact,
  updateContact,
  deleteContact,
} from "../services/contactService";
@Component({
  name: "contact",
  components: {},
  methods: {},
})
export default class Contact extends Vue {
  private dialog: boolean = false;
  private dialogDelete: boolean = false;
  private contacts: IContact[] = [];
  private editedIndex: number = -1;
  private editedItem: IContact = {
    contactId: 0,
    contactName: "",
    birthDate: "",
    contactGroup: "",
    description: "",
    isFavorite: false,
  };
  private defaultItem: IContact = {
    contactId: 0,
    contactName: "",
    birthDate: "",
    contactGroup: "",
    description: "",
    isFavorite: false,
  };

  @Watch("dialog") private onDiaglogChange(newValue: boolean) {
    newValue || this.close();
  }

  @Watch("dialogDelete") private onDialogDeleteChange(newValue: boolean) {
    newValue || this.closeDelete();
  }

  private get formTitle() {
    return this.editedIndex === -1 ? "Add Contact" : " Edit Contact";
  }

  private get headers() {
    return [
      {
        text: "Contact Name",
        value: "contactName",
      },
      { text: "Birth Date", value: "birthDate" },
      { text: "Contact Group", value: "contactGroup" },
      { text: "Description", value: "description" },
      { text: "Is Favorite", value: "isFavorite" },
      { text: "Actions", value: "actions", sortable: false },
    ];
  }

  private created() {
    this.initialize();
  }

  private async initialize() {
    this.contacts = await getContacts();
  }

  private editItem(item: IContact) {
    this.editedIndex = this.contacts.indexOf(item);
    this.editedItem = Object.assign({}, item);
    this.dialog = true;
  }

  private deleteItem(item: IContact) {
    this.editedIndex = this.contacts.indexOf(item);
    this.editedItem = Object.assign({}, item);
    this.dialogDelete = true;
  }

  private async deleteItemConfirm() {
    const res = await deleteContact(this.contacts[this.editedIndex].contactId);
    if (res > 0) {
      this.contacts.splice(this.editedIndex, 1);
    }
    this.closeDelete();
  }

  private close() {
    this.dialog = false;
    this.$nextTick(() => {
      this.editedItem = Object.assign({}, this.defaultItem);
      this.editedIndex = -1;
    });
  }

  private closeDelete() {
    this.dialogDelete = false;
    this.$nextTick(() => {
      this.editedItem = Object.assign({}, this.defaultItem);
      this.editedIndex = -1;
    });
  }

  private async save() {
    if (!(await this.$validator.validateAll())) {
      return;
    }

    let res: number;
    if (this.editedIndex > -1) {
      res = await updateContact(this.editedItem);
    } else {
      res = await addContact(this.editedItem);
    }
    if (res > 0) {
      this.initialize();
    }
    this.close();
  }
}
</script>
<style>
.validation-error {
  font-size: 10px;
  color: red;
}
</style>