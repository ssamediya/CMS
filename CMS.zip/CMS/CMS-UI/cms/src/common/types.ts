export interface IContact {
    contactId: number,
    contactName: string,
    birthDate: string,
    contactGroup: string,
    description: string,
    isFavorite: boolean
}
