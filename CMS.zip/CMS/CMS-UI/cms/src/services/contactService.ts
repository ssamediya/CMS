import { IContact } from "@/common/types";
import axios, { AxiosRequestConfig, AxiosResponse, AxiosError } from "axios";

const serviceBaseUrl = process.env.VUE_APP_API_BASE_URL;

export const getContacts: () => Promise<IContact[]> = async () => {
    const url = serviceBaseUrl + "/GetContacts";
    const res = (await axios.get(url)).data as IContact[];
    return res;
}

export const addContact: (data: IContact) => Promise<number> = async (data) => {
    const url = serviceBaseUrl + "/AddContact";
    const res = (await axios.post(url, data)).data as number;
    return res;
}

export const updateContact: (data: IContact) => Promise<number> = async (data) => {
    const url = serviceBaseUrl + "/UpdateContact";
    const res = (await axios.put(url, data)).data as number;
    return res;
}

export const deleteContact: (contactId: number) => Promise<number> = async (contactId) => {
    const url = serviceBaseUrl + "/DeleteContact?contactId=" + contactId;
    const res = (await axios.delete(url)).data as number;
    return res;
}
